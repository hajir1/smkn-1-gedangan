<?php

use App\Http\Middleware\EnsureUserIsAdmin;
use App\Http\Middleware\MonitorPageErrors;
use App\Http\Middleware\NoStoreCache;
use App\Http\Middleware\SecurityHeaders;
use App\Http\Middleware\TrackVisitor;
use Illuminate\Foundation\Application;
use Illuminate\Foundation\Configuration\Exceptions;
use Illuminate\Foundation\Configuration\Middleware;

return Application::configure(basePath: dirname(__DIR__))
    ->withRouting(
        web: __DIR__.'/../routes/web.php',
        commands: __DIR__.'/../routes/console.php',
        health: '/up',
    )
    ->withMiddleware(function (Middleware $middleware) {
        $middleware->web(append: [
            SecurityHeaders::class,
        ]);

        $middleware->alias([
            'admin' => EnsureUserIsAdmin::class,
            'no-store' => NoStoreCache::class,
            'track-visitor' => TrackVisitor::class,
            'monitor-errors' => MonitorPageErrors::class,
        ]);

    })
    ->withExceptions(function (Exceptions $exceptions) {
        //
    })->create();
